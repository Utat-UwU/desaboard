
<?php $__env->startSection('container'); ?>
<?php
$counter = 0;
?>

<div class="main-content">
    <main>
        <?php if(session()->has('success')): ?>
        <div class="alert alert-success alert-dismissible fade show" role="alert">
        
            <?php echo e(session('success')); ?>


        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
            <span aria-hidden="true">&times;</span>
        </button>
        </div>
        <?php endif; ?>
        <h3>
            Data Penduduk Desa Temboro
        </h3>

        <div class="row">
            <div class="col-md-6">
                <form action="/data">
                    <div class="input-group mb-3">
                        <input type="text" class="form-control" placeholder="Cari..." name="search" value="<?php echo e(request('search')); ?>">
                        <button class="btn btn-outline-secondary" type="submit" >Cari</button>
                      </div>
                </form>
            </div>
        </div>

        <table class="table">
        <thead>
            <tr>
                <th scope="col">#</th>
                <th scope="col">NIK</th>
                <th scope="col">Nama</th>
                <th scope="col">Nomor KK</th>
                <th scope="col">Jenis Kelamin</th>
                <th scope="col">Status Perkawinan</th>
                <th scope="col">Tanggal lahir</th>
                <th scope="col">Pekerjaan</th>
                <th scope="col">Status dalam Keluarga</th>
                <th scope="col">Nomor Telepon</th>
                <th scope="col">Dusun</th>
                <th scope="col"> Action</th>
                
            </tr>
        </thead>
            <tbody>
            <?php if($checker>0): ?>

                        <?php $__currentLoopData = $wargadesa; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $warga): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php
                            $counter++;
                        ?>
                    <tr>
                        <td>
                            <?php echo e($counter); ?>

                            </td>
                        <td>
                            <?php echo e($warga['NIK']); ?>

                            </td>
                        <td>
                            <?php echo e($warga['Nama']); ?>

                            </td>
                        <td>
                            <?php echo e($warga['Nomor_KK']); ?>

                            </td>
                       <td>
                            <?php echo e($warga['Jenis_Kelamin']); ?>

                            </td>
                       <td>
                            <?php echo e($warga['Status_Perkawinan']); ?>

                            </td>
                        <td>
                            <?php echo e($warga['Tanggal_Lahir']); ?>

                            </td>
                        <td>
                           <?php echo e($warga['Pekerjaan']); ?>

                            </td>
                        <td>
                           <?php echo e($warga['Status_Dalam_Keluarga']); ?>

                            </td>
                        <td>
                            <?php echo e($warga['Nomor_Telepon']); ?>

                            </td>
                        <td>
                            <?php $__currentLoopData = $dusuns; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dusun): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
                               <?php if($dusun['DusunID'] == $warga['dusun_id']): ?> 
                                    <?php echo e($dusun['Nama_Dusun']); ?>

                                <?php endif; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </td>
                        <td>
                                <a class="btn btn-primary" href="/data/edit/<?php echo e($warga['WargaID']); ?>" role="button">Edit</a>
                                <form action="/data/delete/<?php echo e($warga['WargaID']); ?>" method="post" class="d-inline">
                                <?php echo method_field('delete'); ?>
                                <?php echo csrf_field(); ?>
                                <button class="btn btn-danger border-0" onclick="return confirm('Anda yakin ingin menghapus data?')">Delete</button>
                                </form>
                            </td> 
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                
            <?php endif; ?>
            
        </tbody>
        </table>
       <?php if($checker>0): ?>
         <?php echo e($wargadesa->links()); ?> 
        <?php endif; ?> 
        <?php if($checker<1): ?>
        <h4> Data Tidak Ditemukan </h4> 
       <?php endif; ?> 
    
        
    </main>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts/main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Github\MPPLProject\desaboard\resources\views/data.blade.php ENDPATH**/ ?>